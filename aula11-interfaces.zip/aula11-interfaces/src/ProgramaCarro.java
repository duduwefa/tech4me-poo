import java.util.InputMismatchException;

import classes.*;
import exceptions.PlacaInvalidaException;

public class ProgramaCarro {
    public static void main(String[] args) {
        
        

    }
}
